import numpy as np
from sklearn.preprocessing import MinMaxScaler
import time
import copy
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.nn.functional
from torch.utils.data import Dataset, DataLoader
import warnings
import torch
import time
import argparse
import json
import os
from transformers import BertTokenizer
# from model_old import BERT_Classifier
from random import choice
import torch
from transformers import BertTokenizer
from sklearn.metrics import precision_recall_fscore_support

import random
def setup_seed(seed):
     torch.manual_seed(seed)
     torch.cuda.manual_seed_all(seed)
     np.random.seed(seed)
     random.seed(seed)
warnings.filterwarnings("ignore")
setup_seed(44)

from transformers import BertModel
from loader import map_id_rel
rel2id, id2rel = map_id_rel()
print(len(rel2id))
print(id2rel)
USE_CUDA = torch.cuda.is_available()

def test(net_path, text_list, ent1_list, ent2_list, result, show_result=False):
    max_length = 512

    net = torch.load(net_path, weights_only=False)
    # net = torch.load(net_path)
    net.eval()
    if USE_CUDA:
        net = net.cuda()
    rel_list = []
    total_correct = 0
    total = 0
    with torch.no_grad():
        for text, ent1, ent2, label in zip(text_list, ent1_list, ent2_list, result):
            sent = ent1 + ent2 + text
            tokenizer = BertTokenizer.from_pretrained('D:\\RE\\bert-base-uncased')
            indexed_tokens = tokenizer.encode(sent, add_special_tokens=True)
            avai_len = len(indexed_tokens)
            # print("len indexed_tokens:", len(indexed_tokens))
            while len(indexed_tokens) < max_length:
                indexed_tokens.append(0)  # 0 is id for [PAD]
            indexed_tokens = indexed_tokens[: max_length]
            indexed_tokens = torch.tensor(indexed_tokens).long().unsqueeze(0)  # (1, L)
            # Attention mask
            att_mask = torch.zeros(indexed_tokens.size()).long()  # (1, L)
            att_mask[0, :avai_len] = 1
            if USE_CUDA:
                indexed_tokens = indexed_tokens.cuda()
                att_mask = att_mask.cuda()
            if USE_CUDA:
                indexed_tokens = indexed_tokens.cuda()
                att_mask = att_mask.cuda()
            outputs = net(indexed_tokens, attention_mask=att_mask)
            if len(outputs) == 1:
                logits = outputs[0]  # 保证和旧模型参数的一致性
            else:
                logits = outputs[1]
                # 获取预测结果
                _, predicted = torch.max(logits.data, 1)
                result_id = predicted.cpu().numpy().tolist()[0]
                rel_list.append(id2rel[result_id])
                # 计算准确率
                if id2rel[result_id] == label:
                    total_correct += 1
                total += 1
                # 计算召回率和F1分数
    precision, recall, f1_score, _ = precision_recall_fscore_support(result, rel_list, average='macro')
    # 输出结果
    print("total_correct:",total_correct)
    print("total:",total)
    print("Accuracy:", total_correct / total)
    print("Recall:", recall)
    print("F1 Score:", f1_score)
    print("precision:", precision)
    return rel_list

def demo_result():
    text_list = []
    ent1 = []
    ent2 = []
    result = []
    total_num = 2497
    with open("test_new.json", 'r', encoding='utf-8') as load_f:
        lines = load_f.readlines()
        while total_num > 0:
            line = choice(lines)
            dic = json.loads(line)
            text_list.append(dic['text'])
            ent1.append(dic['ent1'])
            ent2.append(dic['ent2'])
            result.append(dic['rel'])
            total_num -= 1
            if total_num < 0:
                break
    rel_list = test('0.9536963802711118.pth', text_list, ent1, ent2, result, True)

def test_output(net_path, text_list, ent1_list, ent2_list, result, show_result=False):
    max_length = 128
    net = torch.load(net_path)
    net.eval()
    if USE_CUDA:
        net = net.cuda()
    rel_list = []
    total_correct = 0
    total = 0
    with torch.no_grad():
        for text, ent1, ent2, label in zip(text_list, ent1_list, ent2_list, result):
            sent = ent1 + ent2 + text
            tokenizer = BertTokenizer.from_pretrained('D:\\RE\\bert-base-uncased')
            indexed_tokens = tokenizer.encode(sent, add_special_tokens=True)
            avai_len = len(indexed_tokens)
            # print("len indexed_tokens:",len(indexed_tokens))
            while len(indexed_tokens) < max_length:
                indexed_tokens.append(0)  # 0 is id for [PAD]
            indexed_tokens = indexed_tokens[: max_length]
            indexed_tokens = torch.tensor(indexed_tokens).long().unsqueeze(0)  # (1, L)
            # Attention mask
            att_mask = torch.zeros(indexed_tokens.size()).long()  # (1, L)
            att_mask[0, :avai_len] = 1
            if USE_CUDA:
                indexed_tokens = indexed_tokens.cuda()
                att_mask = att_mask.cuda()
            if USE_CUDA:
                indexed_tokens = indexed_tokens.cuda()
                att_mask = att_mask.cuda()
            outputs = net(indexed_tokens, attention_mask=att_mask)
            if len(outputs) == 1:
                logits = outputs[0]  # 保证和旧模型参数的一致性
            else:
                logits = outputs[1]
                # 获取预测结果
                _, predicted = torch.max(logits.data, 1)
                result_id = predicted.cpu().numpy().tolist()[0]
                rel_list.append(id2rel[result_id])
                # 计算准确率
                if id2rel[result_id] == label:
                    total_correct += 1
                total += 1
        return rel_list

demo_result()
# demo_output()
exit()
