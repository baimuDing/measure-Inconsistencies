#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@Description:       : main function to carry out training and testing
@Author             : Kevinpro
@version            : 1.0
'''
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import time
import copy
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.autograd as autograd
import torch.nn.functional
from torch.utils.data import Dataset, DataLoader
from transformers import AdamW
import warnings
import torch
import time
import argparse
import json
import os
from transformers import BertTokenizer
from transformers import BertForSequenceClassification
#from transformers import BertPreTrainedModel
from transformers import BertModel

from loader import load_train
from loader import load_dev

from loader import map_id_rel
import random
def setup_seed(seed):
     torch.manual_seed(seed)
     torch.cuda.manual_seed_all(seed)
     np.random.seed(seed)
     random.seed(seed)

setup_seed(44)

rel2id, id2rel = map_id_rel()

print(len(rel2id))
print(id2rel)

def get_model():
    labels_num=len(rel2id)
    from model_2 import BERT_Classifier
    model = BERT_Classifier(labels_num)
    return model

model=get_model()
USE_CUDA = torch.cuda.is_available()
print("USE_CUDA:",USE_CUDA)
data=load_train()
train_text=data['text']
train_mask=data['mask']
train_label=data['label']

train_text = [ t.numpy() for t in train_text]
train_mask = [ t.numpy() for t in train_mask]

train_text=torch.tensor(train_text)
train_mask=torch.tensor(train_mask)
train_label=torch.tensor(train_label)

print("--train data--")
print(train_text.shape)
print(train_mask.shape)
print(train_label.shape)

data=load_dev()
dev_text=data['text']
dev_mask=data['mask']
dev_label=data['label']

dev_text = [ t.numpy() for t in dev_text]
dev_mask = [ t.numpy() for t in dev_mask]

dev_text=torch.tensor(dev_text)
dev_mask=torch.tensor(dev_mask)
dev_label=torch.tensor(dev_label)

print("--train data--")
print(train_text.shape)
print(train_mask.shape)
print(train_label.shape)

print("--eval data--")
print(dev_text.shape)
print(dev_mask.shape)
print(dev_label.shape)

if USE_CUDA:
    print("using GPU")
train_dataset = torch.utils.data.TensorDataset(train_text,train_mask,train_label)
dev_dataset = torch.utils.data.TensorDataset(dev_text,dev_mask,dev_label)
val_losses=[]
import torch
from sklearn.metrics import average_precision_score, auc, precision_recall_curve


def eval(net, dataset, batch_size):
    val_losses = []
    train_iter = torch.utils.data.DataLoader(dataset, batch_size, shuffle=False)
    with torch.no_grad():
        correct = 0
        total=0
        iter = 0
        y_true = []
        y_pred = []
        for text,mask, y in train_iter:
            iter += 1
            if text.size(0)!=batch_size:
                break
            text=text.reshape(batch_size,-1)
            mask = mask.reshape(batch_size, -1)

            if USE_CUDA:
                text=text.cuda()
                mask=mask.cuda()
                y=y.cuda()

            outputs= net(text, mask,y)
            loss, logits = outputs[0],outputs[1]
            _, predicted = torch.max(logits.data, 1)
            total += text.size(0)
            correct += predicted.data.eq(y.data).cpu().sum()
            y_true.extend(y.cpu().numpy())
            y_pred.extend(predicted.cpu().numpy())
        acc= (1.0*correct.numpy())/total
        average_precision = average_precision_score(y_true, y_pred)
        val_losses.append(loss.mean().cpu().numpy().tolist())  # 修改这一行
        precision, recall, _ = precision_recall_curve(y_true, y_pred)
        average_precision_pr = auc(recall, precision)
        print("Eval Result: right", correct.cpu().numpy().tolist(), "total", total, "Acc:", acc,"loss:" ,loss.mean().cpu().numpy().tolist())  # 修改这一行
        return acc, average_precision, val_losses

train_losses=[]
#before
def train(net, dataset, num_epochs, learning_rate, batch_size):
    optimizer = optim.SGD(net.parameters(), lr=learning_rate, weight_decay=0.0001)#0.05
    train_iter = torch.utils.data.DataLoader(dataset, batch_size, shuffle=True)
    pre = 0
    for epoch in range(num_epochs):
        net.train()
        correct = 0
        total = 0
        iter = 0
        for text, mask, y in train_iter:
            iter += 1
            optimizer.zero_grad()
            if text.size(0) != batch_size:
                break
            text = text.reshape(batch_size, -1)
            mask = mask.reshape(batch_size, -1)
            if USE_CUDA:
                text = text.cuda()
                mask = mask.cuda()
                y = y.cuda()
            loss, logits = net(text, mask, y)
            loss.backward()
            optimizer.step()
            _, predicted = torch.max(logits.data, 1)
            total += text.size(0)
            correct += predicted.data.eq(y.data).cpu().sum()
        loss = loss.detach().cpu()
        train_losses.append(loss.mean().numpy().tolist())
        print("epoch ", str(epoch), " loss: ", loss.mean().numpy().tolist(), "right", correct.cpu().numpy().tolist(), "total", total, "Acc:", correct.cpu().numpy().tolist() / total)
        val_acc, val_average_precision, val_losses = eval(model, dev_dataset, batch_size)
        if val_average_precision > 0.95:
            pre = val_average_precision
            torch.save(model, str(val_average_precision) + '.pth')
    return


if USE_CUDA:
    model=model.cuda()

train(model,train_dataset,50,0.0005,16)

