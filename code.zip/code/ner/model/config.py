import os
from .general_utils import get_logger
from .data_utils import get_trimmed_glove_vectors, load_vocab, \
        get_processing_word

class Config():
    def __init__(self, load=True):
        """Initialize hyperparameters and load vocabs

        Args:
            load_embeddings: (bool) if True, load embeddings into
                np array, else None

        """
        # directory for training outputs
        if not os.path.exists(self.dir_output):
            os.makedirs(self.dir_output)

        # create instance of logger
        self.logger = get_logger(self.path_log)

        # load if requested (default)
        if load:
            self.load()


    def load(self):
        # 1. vocabulary
        self.vocab_words = load_vocab(self.filename_words)
        self.vocab_tags  = load_vocab(self.filename_tags)
        self.vocab_chars = load_vocab(self.filename_chars)

        self.nwords     = len(self.vocab_words)+1
        self.nchars     = len(self.vocab_chars)+1
        self.ntags      = len(self.vocab_tags)+1

        # 2. get processing functions that map str -> id
        self.processing_word = get_processing_word(self.vocab_words,
                self.vocab_chars, lowercase=True, chars=self.use_chars)
        self.processing_tag  = get_processing_word(self.vocab_tags,
                lowercase=False, allow_unk=False)
        # 3. get pre-trained embeddings
        self.embeddings = (get_trimmed_glove_vectors(self.filename_trimmed)
                if self.use_pretrained else None)

    # general config
    dir_output = "results/test/"
    dir_model  = dir_output + "model.weights/"
    path_log   = dir_output + "log.txt"

    # embeddings
    dim_word = 300
    dim_char = 100

    # glove files
    filename_glove = "data/glove.6B/glove.6B.{}d.txt".format(dim_word)
    # trimmed embeddings (created from glove_filename with build_data.py)
    filename_trimmed = "data/glove.6B.{}d.trimmed.npz".format(dim_word)
    use_pretrained = True

    # filename_dev = 'data8/Valid4.txt'
    # filename_test = 'data8/Test4.txt'
    # filename_train = 'data8/Train4.txt'
    filename_dev = 'data_512_poc/Valid1_old.txt'
    filename_test = 'data_512_poc/Test1_old.txt'
    filename_train = 'data_512_poc/Train1_old.txt'
    max_iter = None

    # filename_words = "data8/words.txt"
    # filename_tags = "data8/tags.txt"
    # filename_chars = "data8/chars.txt"
    filename_words = "data_512_poc/words.txt"
    filename_tags = "data_512_poc/tags.txt"
    filename_chars = "data_512_poc/chars.txt"

    train_embeddings = False
    nepochs = 20
    dropout = 0.90
    batch_size = 12
    lr_method = "adam"
    lr = 0.0005
    lr_decay = 0.9
    clip = -1  # if negative, no clipping
    nepoch_no_imprv = 5
    hidden_size_char = 100
    hidden_size_lstm = 300
    use_crf = True
    use_chars = True
