


import torch
import torch.nn as nn
from transformers import BertModel

class BERT_Classifier(nn.Module):
    def __init__(self, label_num, cnn_filters=250, kernel_size=6, dropout_rate=0):
        super().__init__()
        self.encoder = BertModel.from_pretrained(r'D:\RE\bert') 
        self.dropout = nn.Dropout(dropout_rate)
        self.conv = nn.Conv1d(in_channels=768, out_channels=cnn_filters, kernel_size=kernel_size,
                              padding=kernel_size // 2)
        self.fc = nn.Linear(cnn_filters, label_num)
        self.criterion = nn.CrossEntropyLoss()

    def forward(self, x, attention_mask, label=None):
        # Get the output from BERT
        x = self.encoder(x, attention_mask=attention_mask)[0]

        # Apply dropout to BERT output
        x = self.dropout(x)

        # Reshape for CNN: (batch_size, sequence_length, hidden_size) -> (batch_size, hidden_size, sequence_length)
        x = x.permute(0, 2, 1)

        # Apply convolutional layer
        x = self.conv(x)

        # Apply max pooling over the sequence length dimension
        x = torch.max(x, dim=-1)[0]

        # Apply dropout to CNN output
        x = self.dropout(x)

        # Fully connected layer
        x = self.fc(x)

        if label is None:
            return None, x
        else:
            return self.criterion(x, label), x