from model.data_utils import CoNLLDataset
from model.ner_model import NERModel
# from model.ner_model_base import NERModel

from model.config import Config

 
def main():
    # create instance of config
    config = Config()

    # build model
    model = NERModel(config)
    print("model load over")
    model.build()
    print("model build load over")
    # model.restore_session("results/crf/model.weights/") # optional, restore weights
    # model.reinitialize_weights("proj")

    # create datasets
    dev   = CoNLLDataset(config.filename_dev, config.processing_word,
                         config.processing_tag, config.max_iter)
    print("dev load over")
    train = CoNLLDataset(config.filename_train, config.processing_word,
                         config.processing_tag, config.max_iter)
    print("train load over")
    # train model
    model.train(train, dev)

if __name__ == "__main__":
    main()
